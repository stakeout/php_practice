<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Document</title>
</head>
<body>
<?php
  // if(count($_POST) > 0){
  //   echo 'POST:<br>';
  //   echo '<pre>'.print_r($_POST).'</pre>';
  // }
  function calculator($num1, $num2, $operation){
    $res = '';
    if(isset($_POST['num1']) && isset($_POST['num2']) && isset($_POST['operation'])){
      $num1 = $_POST['num1'];
      $num2 = $_POST['num2'];
      $operation = $_POST['operation'];
      switch($operation){
        case 'minus':
          $res = $num1 - $num2;
          break;
        case 'devide':
          $res = $num1 / $num2;
          break;
        case 'multi':
          $res = $num1 * $num2;
          break;
        default:
          $res = $num1 + $num2;
      }
      return $res;
    }else{
      return $res = "Передайте все нужные данные!";
    }
  }
?>
  <div class='result' style='margin-bottom: 20px;'>Результат операции: <?php echo calculator($_POST['num1'], $_POST['num2'],$_POST['operation']); ?></div>
  <form action="" method='POST'>
    <input type="text" name='num1' value=''>
    <input type="text" name='num2' value=''>
    <input type="submit" name='submit' value='Отправить'>
    <div class="controls" style='margin-top: 30px'>
      <label style='display: block;'>плюс
        <input type="radio" name='operation' value='plus'>
      </label><br>
      <label style='display: block;'>минус
        <input type="radio" name='operation' value='minus'>
      </label><br>
      <label style='display: block;'>делить
        <input type="radio" name='operation' value='devide'>
      </label><br>
      <label style='display: block;'>умножить
        <input type="radio" name='operation' value='multi'>
      </label>
    </div>

  </form>
</body>
</html>