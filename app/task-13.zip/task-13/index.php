<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Document</title>
</head>
<body>
<?php
  function calculator($num1, $num2, $oper = '+'){
    $res = $error = '';
    $num1 = (int)$num1;
    $num2 = (int)$num2;
    $pattern = '/[-*\/+]/';
    if(!preg_match ($pattern, $oper)){
      return $error = 'Вы ввели не верный знак операции, допустимы лишь +, -, /, *';
    }else{
      switch($oper){
        case '-':
          $res = $num1 - $num2;
        break;
        case '/':
          $res = $num1 / $num2;
        break;
        case '*':
          $res = $num1 * $num2;
        break;
        default:
          $res = $num1 + $num2;
      }
    }
      return "Результат операции: $res";
  }
?>
  <div class='result' style='margin-bottom: 20px;'><?php echo calculator(3, 8, '*') ?></div>
</body>
</html>